#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

TRACE = True

class DragonController(object):
	"""ドラゴンのコントローラ。"""

	def __init__(self, a_view):
		"""ドラゴンのコントローラのコンストラクタ。"""
		if TRACE: print(__name__), self.__init__.__doc__

		self._model = a_view._model
		self._view = a_view

		return

	def keyboard(self, key, x, y):
		"""キーボードを処理する。"""
		if TRACE: print(__name__), self.keyboard.__doc__

		if key in "qQ\33":
			sys.exit(0)
		if key == 'r' or key == 'R':
			self._view._angle_x = 0.0
			self._view._angle_y = 0.0
			self._view._angle_z = 0.0
		if key == 'x':
			self._view._angle_x += 1.0
		if key == 'y':
			self._view._angle_y += 1.0
		if key == 'z':
			self._view._angle_z += 1.0
		if key == 'X':
			self._view._angle_x -= 1.0
		if key == 'Y':
			self._view._angle_y -= 1.0
		if key == 'Z':
			self._view._angle_z -= 1.0

		glutPostRedisplay()

		return

	def motion(self, x, y):
		"""マウスボタンを押下しながらの移動を処理する。"""
		if TRACE: print(__name__), self.motion.__doc__

		return

	def mouse(self, button, state, x, y):
		"""マウスボタンを処理する。"""
		if TRACE: print(__name__), self.mouse.__doc__

		return

	@classmethod
	def unit_test(a_class):
		"""
		このクラスおよびサブクラスの単体テストのためのプログラムです。
		"""
		# print(__file__)
		a_name = a_class.__name__

		# print('\n*** Unit Test：{0} ***'.format(a_name))

		return

# end of file