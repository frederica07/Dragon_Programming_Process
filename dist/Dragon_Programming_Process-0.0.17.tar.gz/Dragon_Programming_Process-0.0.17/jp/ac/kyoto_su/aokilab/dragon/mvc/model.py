#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

import urllib

from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

from jp.ac.kyoto_su.aokilab.dragon.mvc.view import DragonView

TRACE = True

class DragonModel(object):
	"""ドラゴンのモデル。"""

	def __init__(self):
		"""ドラゴンのモデルのコンストラクタ。"""
		if TRACE: print(__name__), self.__init__.__doc__

		self._triangles = []
		self._eye_point = [-5.5852450791872 , 3.07847342734 , 15.794105252496]
		self._sight_point = [0.27455347776413 , 0.20096999406815 , -0.11261999607086]
		self._up_vector = [0.1018574904194 , 0.98480906061847 , -0.14062775604137]
		self._fovy = 12.642721790235
		self._display_list = None
		self._view = None

		filename = os.path.join(os.getcwd(), 'dragon.txt')
		if os.path.exists(filename) and os.path.isfile(filename):
			pass
		else:
			url = 'http://www.cc.kyoto-su.ac.jp/~atsushi/Programs/Dragon/dragon.txt'
			urllib.urlretrieve(url, filename)

		with open(filename, "rU") as a_file:
			while True:
				a_string = a_file.readline()
				if len(a_string) == 0: break
				a_list = a_string.split()
				if len(a_list) == 0: continue
				first_string = a_list[0]
				if first_string == "number_of_vertexes":
					number_of_vertexes = int(a_list[1])
				if first_string == "number_of_triangles":
					number_of_triangles = int(a_list[1])
				if first_string == "end_header":
					for n_th in range(number_of_vertexes):
						if (n_th + 1) % 10 == 0: print(n_th)
						else: print(n_th),
					print()
					for n_th in range(number_of_triangles):
						if (n_th + 1) % 10 == 0: print(n_th)
						else: print(n_th),
					print()

		return

	def display_list(self):
		"""ドラゴンのモデルのディスプレイリスト(表示物をコンパイルしたOpenGLコマンド列)を応答する。"""
		if TRACE: print(__name__), self.display_list.__doc__

		if self._display_list == None:
			self._display_list = glGenLists(1)
			glNewList(self._display_list, GL_COMPILE)
			glColor4d(0.5, 0.5, 1.0, 1.0)
			for index, triangle in enumerate(self._triangles):
				if DEBUG: print(index),
				triangle.rendering()
			glEndList()

		return self._display_list

	def open(self):
		"""ドラゴンのモデルを描画するためのOpenGLのウィンドウを開く。"""
		if TRACE: print(__name__), self.open.__doc__

		self._view = DragonView(self)

		glutMainLoop()

		return

	def rendering(self):
		"""ドラゴンのモデルをレンダリングする。"""
		if TRACE: print(__name__), self.rendering.__doc__

		glCallList(self.display_list())

		return

	@classmethod
	def unit_test(a_class):
		"""
		このクラスおよびサブクラスの単体テストのためのプログラムです。
		"""
		# print(__file__)
		a_name = a_class.__name__

		# print('\n*** Unit Test：{0} ***'.format(a_name))

		return

# end of file