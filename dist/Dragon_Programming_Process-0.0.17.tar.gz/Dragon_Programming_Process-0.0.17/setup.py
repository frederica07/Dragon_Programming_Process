#! /usr/bin/env python
# -*- coding: utf-8 -*-

from distutils.core import setup

setup(
	name='Dragon_Programming_Process',
	version='0.0.17',
	description='Example writeen by Python',
	url='http://www.cc.kyoto-su.ac.jp/~g1244181/index.html',
	author='Uemae Daichi（上前 大地）',
	author_email='gorimal6969@gmail.com',
	licence='2-clause BSD license',
	long_description='ドラゴンのプログラミング・リファクタリング過程（頂点数と三角形数を獲得し、頂点群と三角形群のループを廻ってみる）',
	platform='Mac OS X(10.10.1)',
	packages=['jp'],
)
