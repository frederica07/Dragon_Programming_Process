#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

from jp.ac.kyoto_su.aokilab.dragon.mvc.controller import DragonController

TRACE = True

class DragonView(object):
	"""ドラゴンのビュー。"""

	def __init__(self, a_model):
		"""ドラゴンのビューのコンストラクタ。"""
		if TRACE: print(__name__), self.__init__.__doc__

		self._model = a_model
		self._controller = DragonController(self)
		self._angle_x = 0.0
		self._angle_y = 0.0
		self._angle_z = 0.0
		self._width = 400
		self._height = 400

		glutInit(sys.argv)
		glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH)
		glutInitWindowPosition(100, 100)
		glutInitWindowSize(self._width, self._height)
		glutCreateWindow("Dragon")

		glutDisplayFunc(self.display)
		glutReshapeFunc(self.reshape)
		glutKeyboardFunc(self._controller.keyboard)
		glutMouseFunc(self._controller.mouse)
		glutMotionFunc(self._controller.motion)

		glEnable(GL_COLOR_MATERIAL)
		glEnable(GL_DEPTH_TEST)
		glDisable(GL_CULL_FACE)
		glEnable(GL_NORMALIZE)

		return

	def display(self):
		"""OpenGLで描画する。"""
		if TRACE: print(__name__), self.display.__doc__

		return

	def reshape(self, width, height):
		"""OpenGLを再形成する。"""
		if TRACE: print(__name__), self.reshape.__doc__

		self._width = width
		self._height = height

		glViewport(0, 0, width, height)

		return

	@classmethod
	def unit_test(a_class):
		"""
		このクラスおよびサブクラスの単体テストのためのプログラムです。
		"""
		# print(__file__)
		a_name = a_class.__name__

		# print('\n*** Unit Test：{0} ***'.format(a_name))

		return

# end of file