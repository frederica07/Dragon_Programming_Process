#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

import urllib

from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

from jp.ac.kyoto_su.aokilab.dragon.mvc.view import *
from jp.ac.kyoto_su.aokilab.dragon.mvc.controller import OpenGLController
from jp.ac.kyoto_su.aokilab.dragon.opengl.triangle import OpenGLTriangle
from jp.ac.kyoto_su.aokilab.dragon.opengl.polygon import OpenGLPolygon

TRACE = True
DEBUG = False


class OpenGLModel(object):
	"""OpenGLモデル。"""

	def __init__(self):
		"""OpenGLモデルのコンストラクタ。"""
		if TRACE: print(__name__), self.__init__.__doc__

		self._display_object = []
		self._eye_point = None
		self._sight_point = None
		self._up_vector = None
		self._fovy = self._default_fovy = None
		self._display_list = None
		self._view = None

		return

	def default_controllerew_class(self):
		"""OpenGLモデルを表示するデフォルトのビューのクラスを応答する。"""
		if TRACE: print(__name__), self.default_controllerew_class.__doc__

		return OpenGLController

	def default_view_class(self):
		"""OpenGLモデルを表示するデフォルトのビューのクラスを応答する。"""
		if TRACE: print(__name__), self.default_view_class.__doc__

		return OpenGLView

	def default_window_title(self):
		"""OpenGLウィンドウのタイトル(ラベル)を応答する。"""
		if TRACE: print(__name__), self.default_window_title.__doc__

		return "Untitled"

	def display_list(self):
		"""OpenGLモデルのディスプレイリスト(表示物をコンパイルしたOpenGLコマンド列)を応答する。"""
		if TRACE: print(__name__), self.display_list.__doc__

		if self._display_list == None:
			self._display_list = glGenLists(1)
			glNewList(self._display_list, GL_COMPILE)
			glColor4d(0.5, 0.5, 1.0, 1.0)
			for index, each in enumerate(self._display_object):
				if DEBUG: print(index),
				each.rendering()
			glEndList()

		return self._display_list

	def open(self):
		"""OpenGLモデルを描画するためのOpenGLのウィンドウを開く。"""
		if TRACE: print(__name__), self.open.__doc__

		view_class = self.default_view_class()
		self._view = view_class(self)

		return

	def rendering(self):
		"""OpenGLモデルをレンダリングする。"""
		if TRACE: print(__name__), self.rendering.__doc__

		glCallList(self.display_list())

		return

	@classmethod
	def unit_test(a_class):
		"""
		このクラスおよびサブクラスの単体テストのためのプログラムです。
		"""
		# print(__file__)
		a_name = a_class.__name__

		# print('\n*** Unit Test：{0} ***'.format(a_name))

		return


class DragonModel(OpenGLModel):
	"""ドラゴンのモデル。"""

	def __init__(self):
		"""ドラゴンのモデルのコンストラクタ。"""
		if TRACE: print(__name__), self.__init__.__doc__

		super(DragonModel, self).__init__()
		self._eye_point = [-5.5852450791872 , 3.07847342734 , 15.794105252496]
		self._sight_point = [0.27455347776413 , 0.20096999406815 , -0.11261999607086]
		self._up_vector = [0.1018574904194 , 0.98480906061847 , -0.14062775604137]
		self._fovy = self._default_fovy = 12.642721790235

		filename = os.path.join(os.getcwd(), 'dragon.txt')
		if os.path.exists(filename) and os.path.isfile(filename):
			pass
		else:
			url = 'http://www.cc.kyoto-su.ac.jp/~atsushi/Programs/Dragon/dragon.txt'
			urllib.urlretrieve(url, filename)

		with open(filename, "rU") as a_file:
			while True:
				a_string = a_file.readline()
				if len(a_string) == 0: break
				a_list = a_string.split()
				if len(a_list) == 0: continue
				first_string = a_list[0]
				if first_string == "number_of_vertexes":
					number_of_vertexes = int(a_list[1])
				if first_string == "number_of_triangles":
					number_of_triangles = int(a_list[1])
				if first_string == "end_header":
					get_tokens = (lambda file: file.readline().split())
					collection_of_vertexes = []
					for n_th in range(number_of_vertexes):
						a_list = get_tokens(a_file)
						a_vertex = map(float, a_list[0:3])
						collection_of_vertexes.append(a_vertex)
					index_to_vertex = (lambda index: collection_of_vertexes[index-1])
					for n_th in range(number_of_triangles):
						a_list = get_tokens(a_file)
						indexes = map(int, a_list[0:3])
						vertexes = map(index_to_vertex, indexes)
						a_tringle = OpenGLTriangle(*vertexes)
						self._display_object.append(a_tringle)

		return

	def default_window_title(self):
		"""ドラゴンのウィンドウのタイトル(ラベル)を応答する。"""
		if TRACE: print(__name__), self.default_window_title.__doc__

		return "Dragon"


class WaspModel(OpenGLModel):
	"""スズメバチのモデル。"""

	def __init__(self):
		"""スズメバチのモデルのコンストラクタ。"""
		if TRACE: print(__name__), self.__init__.__doc__

		super(WaspModel, self).__init__()
		self._eye_point = [-5.5852450791872 , 3.07847342734 , 15.794105252496]
		self._sight_point = [0.19825005531311 , 1.8530999422073 , -0.63795006275177]
		self._up_vector = [0.070077999093727 , 0.99630606032682 , -0.049631725731267]
		self._fovy = self._default_fovy = 41.480099231656

		filename = os.path.join(os.getcwd(), 'wasp.txt')
		if os.path.exists(filename) and os.path.isfile(filename):
			pass
		else:
			url = 'http://www.cc.kyoto-su.ac.jp/~atsushi/Programs/Wasp/wasp.txt'
			urllib.urlretrieve(url, filename)

		with open(filename, "rU") as a_file:
			while True:
				a_string = a_file.readline()
				if len(a_string) == 0: break
				a_list = a_string.split()
				if len(a_list) == 0: continue
				first_string = a_list[0]
				if first_string == "number_of_vertexes":
					number_of_vertexes = int(a_list[1])
				if first_string == "number_of_polygons":
					number_of_polygons = int(a_list[1])
				if first_string == "end_header":
					get_tokens = (lambda file: file.readline().split())
					collection_of_vertexes = []
					for n_th in range(number_of_vertexes):
						a_list = get_tokens(a_file)
						a_vertex = map(float, a_list[0:3])
						collection_of_vertexes.append(a_vertex)
					index_to_vertex = (lambda index: collection_of_vertexes[index-1])
					for n_th in range(number_of_polygons):
						a_list = get_tokens(a_file)
						number_of_indexes = int(a_list[0])
						index = number_of_indexes + 1
						indexes = map(int, a_list[1:index])
						vertexes = map(index_to_vertex, indexes)
						rgb_color = map(float, a_list[index:index+3])
						a_polygon = OpenGLPolygon(vertexes, rgb_color)
						self._display_object.append(a_polygon)

		return

	def default_view_class(self):
		"""スズメバチのモデルを表示するデフォルトのビューのクラスを応答する。"""
		if TRACE: print(__name__), self.default_view_class.__doc__

		return WaspView

	def default_window_title(self):
		"""スズメバチのウィンドウのタイトル(ラベル)を応答する。"""
		if TRACE: print(__name__), self.default_window_title.__doc__

		return "Wasp"

# end of file