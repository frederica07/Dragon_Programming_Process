#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

class DragonModel(object):
	"""ドラゴンのモデル。"""

	pass

# end of file