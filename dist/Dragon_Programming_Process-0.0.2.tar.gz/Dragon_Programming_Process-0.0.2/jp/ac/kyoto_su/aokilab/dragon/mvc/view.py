#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

class DragonView(object):
	"""ドラゴンのビュー。"""

	pass

# end of file