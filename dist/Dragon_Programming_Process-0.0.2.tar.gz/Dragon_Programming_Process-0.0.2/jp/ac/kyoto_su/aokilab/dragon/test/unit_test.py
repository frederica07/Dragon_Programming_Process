#! /usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

from jp.ac.kyoto_su.aokilab.dragon.mvc.model import DragonModel
from jp.ac.kyoto_su.aokilab.dragon.mvc.view import DragonView
from jp.ac.kyoto_su.aokilab.dragon.mvc.controller import DragonController
from jp.ac.kyoto_su.aokilab.dragon.opengl.triangle import DragonTriangle

class UnitTest(object):
	"""
	単体テストのためのクラスです。
	"""

	"""
	def __init__(self):

		# MVCの単体テスト(Model,View,Controllerというレシーバに対してunit_test()というメッセージを送っている)
		.unit_test()

		return
	"""

# end of file