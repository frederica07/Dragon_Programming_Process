#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

class DragonController(object):
	"""ドラゴンのコントローラ。"""

	pass

# end of file