#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

class DragonTriangle(object):
	"""ドラゴンの三角形。"""

	pass

# end of file