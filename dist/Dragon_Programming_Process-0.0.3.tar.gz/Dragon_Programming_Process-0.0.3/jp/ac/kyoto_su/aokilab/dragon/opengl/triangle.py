#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

DEBUG = False

class DragonTriangle(object):
	"""ドラゴンの三角形。"""

	def __init__(self, vertex1, vertex2, vertex3):
		"""ドラゴンの三角形のコンストラクタ。"""
		if DEBUG: print(__name__), self.__init__.__doc__

		self._vertex1 = vertex1
		self._vertex2 = vertex2
		self._vertex3 = vertex3

		return

	@classmethod
	def unit_test(a_class):
		"""
		このクラスおよびサブクラスの単体テストのためのプログラムです。
		"""
		# print(__file__)
		a_name = a_class.__name__

		# print('\n*** Unit Test：{0} ***'.format(a_name))

		return

# end of file