#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

TRACE = True

class DragonController(object):
	"""ドラゴンのコントローラ。"""

	def __init__(self, a_view):
		"""ドラゴンのコントローラのコンストラクタ。"""
		if TRACE: print(__name__), self.__init__.__doc__

		self._model = a_view._model
		self._view = a_view

		return

	@classmethod
	def unit_test(a_class):
		"""
		このクラスおよびサブクラスの単体テストのためのプログラムです。
		"""
		# print(__file__)
		a_name = a_class.__name__

		# print('\n*** Unit Test：{0} ***'.format(a_name))

		return

# end of file